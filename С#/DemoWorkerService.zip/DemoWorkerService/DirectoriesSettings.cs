﻿namespace DemoWorkerService {
    public class DirectoriesSettings {
        public static readonly string DirectoriesKey = "Directories";

        public string[] Paths { get; set; }
    }
}