using Microsoft.Extensions.Options;
using System.Text;

namespace DemoWorkerService {
    public class Worker : BackgroundService {
        private readonly ILogger<Worker> _logger;
        private readonly DirectoriesSettings directoriesSettings;

        public Worker(IOptions<DirectoriesSettings> options, ILogger<Worker> logger) {
            _logger = logger;
            directoriesSettings = options.Value ?? throw new ArgumentNullException(nameof(DirectoriesSettings));
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken) {
            while (!stoppingToken.IsCancellationRequested) {
                _logger.LogInformation("Worker running at: {time}", DateTimeOffset.Now);
                var details = GetDirectoriesDetails(directoriesSettings.Paths);
                _logger.LogInformation(details);
                await Task.Delay(TimeSpan.FromSeconds(10), stoppingToken);
            }
        }

        public override Task StartAsync(CancellationToken cancellationToken) {
            _logger.LogInformation($"{nameof(Worker)}: Start");
            return base.StartAsync(cancellationToken);
        }

        public override Task StopAsync(CancellationToken cancellationToken) {
            _logger.LogInformation($"{nameof(Worker)} stopping.");
            return base.StopAsync(cancellationToken);
        }

        private string GetDirectoriesDetails(string[] paths) {
            var sb = new StringBuilder();
            foreach (var path in paths) {
                sb.AppendLine($"Explore: {path}");
                sb.AppendLine(GetDirectoryDetails(path));
            }
            return sb.ToString();
        }

        private string GetDirectoryDetails(string path) {
            StringBuilder stringBuilder = new StringBuilder();
            var directories = Directory.GetDirectories(path);
            var files = Directory.GetFiles(path);
            if (!directories.Any()) {
                stringBuilder.AppendLine("Directories not found");
            }
            else {
                
                stringBuilder.AppendLine("Directories:");
                stringBuilder.AppendLine(string.Join("; ", directories));
            }

            if (!files.Any()) {
                stringBuilder.AppendLine("Files not found");
            }
            else {
                stringBuilder.AppendLine("Files:");
                stringBuilder.AppendLine(string.Join("; ", files));
            }

            return stringBuilder.ToString();
        }
    }
}